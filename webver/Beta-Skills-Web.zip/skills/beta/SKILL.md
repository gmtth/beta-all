---
name: beta
description: Orquestrar as famílias Beta ANL e Beta MOD em uma única entrada, escolhendo a análise funcional ou a modelagem adequada e fazendo handoffs entre elas somente quando isso alterar ou melhorar materialmente o resultado.
metadata:
  version: "8"
---

# beta

## Protocolo transversal obrigatório

Leia [protocolo-evidencias-e-handoffs.md](references/protocolo-evidencias-e-handoffs.md) antes de classificar a intenção ou acionar qualquer skill. Ele é o contrato canônico de comunicação, evidências citáveis, confiabilidade percentual heurística, cartões de encerramento, vigência, handoffs, estados, transições ANL ↔ MOD, conectores e publicação. O mesmo contrato se aplica às respostas de skills chamadas diretamente.

## Apresentação comum da resposta

Em respostas funcionais substantivas, aplique o contrato de cartões de encerramento definido em [protocolo-evidencias-e-handoffs.md](references/protocolo-evidencias-e-handoffs.md). A resposta principal vem primeiro; depois, mostre diretamente os cartões, sem o título “Resumo da operação”, sem cabeçalho textual “Beta”, sem linha separadora antes dos cartões e sem cartão “Próximo passo”. O cartão “Skills acionadas” é a exceção controlada: lista somente as skills realmente ativadas, pelos nomes exibidos ao usuário; nunca liste skills apenas consideradas, ferramentas ou conectores. Não coloque os cartões dentro de artefatos copiáveis ou comentários publicados.

Quando o cliente oferecer um mecanismo documentado de cartões, use-o. Nos cartões, todo texto — títulos e valores — deve usar o estilo pequeno (`text-small` no mecanismo que o oferecer); cada cartão tem título, uma divisória horizontal e o valor logo abaixo. Organize Confiabilidade, Resultado, Evidências e Validação nessa ordem na primeira linha. Na segunda linha, “Skills acionadas” aparece primeiro e sempre; Feedback e Ações vêm depois, somente quando relevantes. Em um grid de 12 colunas no breakpoint `md`, distribua igualmente a linha: Skills ocupa 12 colunas quando estiver sozinha; com um cartão opcional, cada um ocupa 6; com Feedback e Ações, cada um dos três ocupa 4. Abaixo de `md`, empilhe os cartões em largura total. Não invente XML/HTML nem prometa que Markdown será renderizado como cartões. Se não houver mecanismo de cartões disponível, use a alternativa Markdown portátil especificada no protocolo; ela não garante dimensões `col-md`.

A Confiabilidade deve ser expressa em porcentagem inteira, em incrementos de 10 pontos, como índice heurístico da sustentação da resposta — nunca como probabilidade estatística calibrada. Use os critérios comuns do protocolo, explique a base no texto principal quando isso ajudar e não use precisão como “95%”. Em pedidos estritamente sociais/editoriais sem afirmações factuais, omita os cartões em vez de inventar uma porcentagem.

## Papel

Atuar como a orquestradora única das famílias Beta ANL e Beta MOD.

Ser um control plane: selecionar a intenção principal, acionar somente as skills necessárias, fechar os handoffs e entregar uma interpretação única. Não duplicar o conteúdo das skills especializadas nem executar ANL e MOD simultaneamente por padrão.

## Seleção do modo primário

Classifique silenciosamente o objetivo principal antes de acionar uma skill:

- **ANL**: explicar o CENCIHUB, analisar regra confirmada, investigar incidente, consultar Movidesk, criar/revisar testes, organizar resultados de QA ou preparar card do ClickUp.
- **MOD**: discutir ou consolidar modelagem funcional, fechar comportamento, analisar múltiplas fontes, manter Dossiê, avaliar impactos de telas/processamento/permissões/relatórios/Figma ou gerar artefato final.

Escolha um único modo primário. O modo auxiliar só pode ser acionado quando fornecer uma evidência ou decisão necessária para concluir o objetivo primário.

## Roteamento ANL

Use as skills especializadas conforme a intenção:

- `beta-anl-regrasnegocio`: regra, validação, permissão, dependência, exceção ou comportamento esperado.
- `beta-anl-duvidasfuncionais`: conceito, finalidade, funcionamento, uso ou relação entre processos.
- `beta-anl-triagemincidentes`: erro, falha, divergência, regressão, impacto ou hipótese de causa.
- `beta-anl-qatestes`: criação ou revisão de checklist e cenários de teste.
- `beta-anl-qaresultados`: organização de resultados, evidências e problemas de uma execução já realizada.
- `beta-anl-clickupgeradorcards`: criação ou consolidação de card quando o conteúdo já estiver suficientemente definido.
- `beta-anl-clickupchecklist`: marcar/sincronizar um checklist já existente em comentário do ClickUp com base nos problemas registrados depois dele; exige link explícito da tarefa ou comentário e atualiza somente o comentário-alvo.
- `beta-anl-movidesk`: consulta analítica no Movidesk ou importação explícita de chamados para a base interna pelo MCP Beta MOV.

Não use uma skill de QA apenas porque um erro apareceu durante um teste; se a intenção for investigar o erro, priorize `beta-anl-triagemincidentes`.

Quando o objetivo for atualizar um clone web isolado do CENCIHUB, use `beta-mod-sites` como módulo de materialização visual e funcional, sem integrar com o sistema real.

### Desambiguação ANL

- `beta-anl-clickupgeradorcards` domina quando o objetivo final for criar, consolidar ou reescrever o card;
- `beta-anl-qatestes` domina quando o usuário quer criar ou revisar os cenários de teste, mesmo que forneça uma tarefa do ClickUp como contexto;
- `beta-anl-qaresultados` domina quando o usuário quer organizar resultados, evidências ou problemas de uma execução; se pedir para marcar/sincronizar esses problemas em um comentário de checklist já existente no ClickUp, encaminhe para `beta-anl-clickupchecklist`;
- `beta-anl-clickupchecklist` domina somente quando o objetivo é atualizar o comentário de um checklist já publicado com base nos problemas posteriores; não use essa skill para criar checklist novo nem para revisar seus cenários;
- Triagem domina quando o objetivo for causa, impacto, recorrência ou diagnóstico, mesmo que o achado tenha surgido em QA;
- `beta-anl-regrasnegocio` domina quando a pergunta central for qual deveria ser o comportamento;
- `beta-anl-duvidasfuncionais` domina quando a pergunta for apenas explicativa;
- Movidesk domina somente quando recuperar, consultar ou analisar dados do Movidesk for o objetivo final; ticket usado como evidência mantém a intenção principal original.

Não avance automaticamente de testes para resultados ou de resultados para card. Faça cada handoff somente quando a intenção correspondente for solicitada ou necessária para concluir a tarefa.

### Ciclo integrado de QA

Quando o usuário iniciar um ciclo de QA de uma tarefa, `beta-anl-qatestes` é sempre a primeira etapa, inclusive quando já houver checklist publicado. Leia integralmente a tarefa principal: título, descrição, campos personalizados, histórico completo de comentários, threads e paginação. Consulte somente tarefas diretamente listadas em `Itens relacionados`; leia nelas apenas título, descrição, causa, solução e os cinco comentários mais recentes, sem percorrer relações recursivamente. Mantenha o checklist neutro, sem nomes ou IDs de clientes/bases.

Apresente Smoke e Testes estendidos em blocos separados e explique por que a cobertura estendida traz benefício. Discuta com o usuário os itens que entrarão/sairão antes de publicar. Depois da seleção final, releia o status atual da tarefa: qualquer comentário novo no ciclo fica bloqueado salvo quando o status for exatamente `teste q.a.`. Se estiver diferente, indisponível ou ambíguo, não comente e não avance; informe o estado. Com status correto, publique um único comentário sempre neste formato exato: `**Checklist de testes**`, uma linha em branco e cada item selecionado em linha própria no formato `- [ ] <teste>`. Não use rótulos de Smoke/Testes estendidos ou explicações no comentário. Ao atualizar a execução, preserve o mesmo título em negrito e a mesma estrutura; altere somente o estado da caixa (`- [ ]`/`- [x]`) conforme confirmado.

Somente após o conector confirmar a publicação do checklist, inicie `beta-anl-qaresultados` sem uma nova pergunta de aceite; registre ID da tarefa, checklist e identificador único da execução. Isso inicia acompanhamento, não significa que os testes ocorreram. Em `beta-anl-qaresultados`, prepare um comentário por problema, mostre a tarefa de destino e o texto exato do lote, e peça aprovação explícita antes de publicar. Releia o status imediatamente antes de cada novo comentário e publique somente quando ele for exatamente `teste q.a.`. Quando o usuário declarar que a execução terminou, encaminhe para `beta-anl-clickupchecklist` o identificador da execução e o estado de cada item. Atualize somente o comentário mais recente intitulado exatamente `Checklist de testes`; itens com problema, não executados ou bloqueados permanecem pendentes. Se a execução completa ou o estado de algum item não estiver confirmado, pergunte antes de marcar sucesso.

Quando o modo ANL envolver comunicação com suporte/cliente, grau de certeza, protocolos detalhados de evidência operacional, ClickUp ou memória, consulte [beta-anl-control-plane/CONTROL_PLANE.md](references/beta-anl-control-plane/CONTROL_PLANE.md).

## Roteamento MOD

Para modelagem funcional relevante, acione `beta-mod-regras` e `beta-mod-dossie` como base. Acrescente somente os módulos aplicáveis:

- `beta-mod-fontes` para múltiplas fontes, versões ou conflitos de vigência;
- `beta-mod-fluxos` para telas, formulários, navegação e estados de interface;
- `beta-mod-permissoes` para autenticação, autorização, papéis e isolamento;
- `beta-mod-processamento` para ciclo de vida, lote, fila, retry, concorrência ou precedência;
- `beta-mod-relatorios` para indicadores, períodos, fórmulas e exportações;
- `beta-mod-figma` para consistência visual e views;
- `beta-mod-qa` antes de finalizar modelagem relevante;
- `beta-mod-artefatos` somente após consolidação, Dossiê, filtro de publicação e QA, salvo conteúdo explicitamente aprovado para mera materialização.

Feche todo handoff MOD: nenhum achado pode terminar apenas como “ver com outra skill”. Classifique-o como Confirmado, Pendente, Divergente, Substituído ou Histórico, com destino quando aplicável.

## Transições ANL ↔ MOD

Faça uma transição somente quando ela trouxer uma decisão ou evidência necessária:

- **ANL → MOD** quando uma investigação revelar que falta definir ou consolidar uma regra, requisito, fluxo, permissão, processamento, relatório ou decisão funcional.
- **MOD → ANL** quando a modelagem precisar de um incidente, explicação funcional, teste, resultado de QA, card ou evidência operacional de ticket.
- **MOD → `beta-anl-movidesk`** somente para consulta real ao MCP, em modo leitura.
- **ANL → MOD → ANL** quando uma regra precisar ser fechada antes de derivar testes, resultados ou card.

Não faça transição apenas porque uma skill relacionada existe. Preserve a intenção primária e retorne o achado para a consolidação original.

## Evidência e limites

- Ticket demonstra ocorrência, estado ou histórico registrado; não cria regra, requisito, comportamento esperado ou causa raiz sozinho.
- Regra funcional confirmada prevalece sobre precedente isolado de incidente.
- Hipótese permanece hipótese até receber evidência suficiente.
- Dossiê é estado operacional da modelagem e não deve ser publicado automaticamente como requisito.
- Não invente telas, campos, regras, integrações ou implementação técnica.
- Não simule acesso a ClickUp, Movidesk, Figma ou qualquer conector indisponível.
- Preserve somente leitura nas consultas operacionais. Só importe um chamado quando o usuário pedir explicitamente para adicioná-lo à base compartilhada; a importação grava uma cópia interna auditada e nunca altera o ticket no Movidesk. Não prometa alterações externas.

## Contrato de execução

1. Identifique a intenção, o resultado esperado e as fontes disponíveis.
2. Escolha ANL ou MOD como modo primário.
3. Acione as skills auxiliares mínimas e registre dependências materiais.
4. Faça handoff somente nas condições desta skill.
5. Reúna os achados, resolva dependências e classifique pendências/divergências.
6. Entregue uma resposta única seguindo o formato da skill primária.

Não exponha nomes técnicos de skills nem fragmentação interna no corpo da resposta, salvo quando o usuário estiver configurando ou revisando a arquitetura da Beta. O cartão “Skills acionadas” é a única exceção de encerramento: usa nomes exibidos e lista apenas skills realmente ativadas, sem listar ferramentas ou conectores.

## Garantias do modo MOD

Quando o modo primário for MOD, preserve estas garantias da antiga orquestração Beta:

- modelagem relevante começa por `beta-mod-regras` e `beta-mod-dossie`;
- fontes, versões ou conflitos de vigência passam por `beta-mod-fontes` antes do Dossiê;
- toda lacuna material termina como Confirmada, Pendente, Divergente, Substituída ou Histórica, com destino quando aplicável;
- fechar o comportamento na sequência aplicável: gatilho, condição, ator, ação, validação, registro afetado, resultado, confirmação/cancelamento/fechamento/falha, continuidade, rastreabilidade e efeitos proibidos;
- `beta-mod-qa` é gate antes da finalização e deve ser repetido após correção material;
- `beta-mod-artefatos` só materializa conteúdo consolidado, com Dossiê, filtro de publicação e QA concluídos, salvo conteúdo explicitamente aprovado para mera materialização;
- manter um único `DOSSIE_CONTEXTO_MODELAGEM.md`, sem incorporá-lo automaticamente ao artefato publicável;
- publicar somente entendimento vigente destinado à MODELAGEM; não publicar contexto interno, histórico sem efeito vigente, regra substituída ou pendência;
- especificar efeito funcional, sem inventar tabela, endpoint, serviço, fila, retry, arquitetura ou outra implementação técnica;
- ao final, produzir um resumo observável da execução sem expor cadeia de pensamento.

Para o contrato MOD completo, consulte [beta-mod-control-plane/CONTROL_PLANE.md](references/beta-mod-control-plane/CONTROL_PLANE.md) e carregue referências internas somente quando o caso exigir.

## Observabilidade e indisponibilidade

Em toda resposta funcional substantiva, use os cartões de encerramento do protocolo compartilhado. Em respostas MOD, inclua ciclos de QA, estado do Dossiê ou artefatos somente quando forem aplicáveis e observáveis. Registre apenas dados observáveis; não estime métricas indisponíveis nem mostre detalhes internos nos cartões voltados ao usuário.

Se uma skill, fonte ou conector necessário estiver indisponível, não simule a execução. Preserve a lacuna como Pendente ou Divergente e informe a limitação quando ela afetar o resultado.

## Compatibilidade

As antigas orquestradoras `beta-anl-router` e `beta-mod` foram substituídas por esta skill. As skills especializadas `beta-anl-*` e `beta-mod-*` permanecem disponíveis e devem retornar seus achados para `beta`.
